# Sequencing Solver

This is a package for solving sequencing problems. All you have to do is to pass the appropriate form of data structure to the corresponding solver. The solver will run the algorithm and return the optimal sequence and the Gantt chart.

The whole point of this package is to enable students and instructors to easily access the solution and code of the solvers' algorithm.

there will be more algorithms featuring this package.
